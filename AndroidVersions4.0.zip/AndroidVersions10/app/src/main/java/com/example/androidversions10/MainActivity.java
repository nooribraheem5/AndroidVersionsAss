package com.example.androidversions10;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.androidversions10.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding mainBinding;
    private ArrayList<AndroidVersion> arrayVersions = new ArrayList<>();
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        mainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(mainBinding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // إضافة عناصر إصدار Android إلى القائمة
        arrayVersions.add(new AndroidVersion(R.drawable.donut, "Donut", "1.6"));
        arrayVersions.add(new AndroidVersion(R.drawable.gingerbread, "Gingerbread", "2.3 – 2.3.7"));
        arrayVersions.add(new AndroidVersion(R.drawable.lollipop, "Lollipop", "5.0 – 5.1.1"));
        arrayVersions.add(new AndroidVersion(R.drawable.eclair, "Eclair", "2.0 - 2.1"));
        arrayVersions.add(new AndroidVersion(R.drawable.froyo, "Froyo", "2.2 - 2.2.3"));
        arrayVersions.add(new AndroidVersion(R.drawable.marshmallow, "Marshmallow", "6.0 – 6.0.1"));
        arrayVersions.add(new AndroidVersion(R.drawable.nougat, "Nougat", "7.0 – 7.1.2"));
        arrayVersions.add(new AndroidVersion(R.drawable.oreo, "Oreo", "8.0 – 8.1"));
        arrayVersions.add(new AndroidVersion(R.drawable.jelly, "Jelly Bean", "4.1 – 4.3.1"));
        arrayVersions.add(new AndroidVersion(R.drawable.kitkat, "KitKat", "4.4 – 4.4.4"));
        arrayVersions.add(new AndroidVersion(R.drawable.honeycomb, "Honeycomb", "3.0 – 3.2.6"));
        arrayVersions.add(new AndroidVersion(R.drawable.icecreamsandwich, "Ice Cream Sandwich ", "4.0 – 4.0.4"));


        // إنشاء محول وتعيينه إلى RecyclerView
        AndroidVersionAdapter adapter = new AndroidVersionAdapter(this, arrayVersions);
        mainBinding.recyclerView.setAdapter(adapter);
        // تعيين مدير التخطيط إلى RecyclerView
        mainBinding.recyclerView.setLayoutManager(new LinearLayoutManager(this));



        // تعيين مستمع النقر لزر التحديث
        mainBinding.refrechButton.setOnClickListener(view -> {

            // Sort list by code name alphabetically
            Collections.sort(arrayVersions, new Comparator<AndroidVersion>() {
                @Override
                public int compare(AndroidVersion v1, AndroidVersion v2) {
                    return v1.codeName.compareTo(v2.codeName);
                }
            });

            // إخطار المحول بأن البيانات قد تغيرت
            adapter.notifyDataSetChanged();
        });











    }



}