package com.example.androidversions10;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.core.content.ContextCompat;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.androidversions10.databinding.CardviewBinding;

import java.util.ArrayList;

public class AndroidVersionAdapter extends RecyclerView.Adapter<AndroidVersionAdapter.AndroidViewHolder> {
    private Context context;
    private ArrayList<AndroidVersion> androidVersions;

    public AndroidVersionAdapter(Context context , ArrayList<AndroidVersion> androidVersions){
        this.context=context;
        this.androidVersions=androidVersions;
    }
    @NonNull
    @Override
    public AndroidViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        CardviewBinding cardviewBinding =CardviewBinding.inflate(LayoutInflater.from(context),parent,false);
        return new AndroidViewHolder(cardviewBinding);
    }
    @Override
    public void onBindViewHolder(@NonNull AndroidViewHolder holder, int position) {

        AndroidVersion version = androidVersions.get(position);
        holder.cardBinding.imageView.setImageResource(version.imageResId);
        holder.cardBinding.txtNameVersion.setText(version.codeName);
        holder.cardBinding.txtVersion.setText(version.version);

        if (position % 2 == 0) {  holder.itemView.setBackgroundColor(ContextCompat.getColor(context, R.color.backgroundEven));}
        else holder.itemView.setBackgroundColor(ContextCompat.getColor(context, R.color.backgroundOdd));

        holder.itemView.setOnClickListener(v -> {Toast.makeText(context, "You Selected : "+version.codeName +"("+ version.version+")", Toast.LENGTH_SHORT).show();
        });
    }
    @Override
    public int getItemCount() {
        return androidVersions.size();
    }
    public static class AndroidViewHolder extends RecyclerView.ViewHolder {
        private final CardviewBinding cardBinding ;
        public AndroidViewHolder(CardviewBinding cardviewBinding) {
            super(cardviewBinding.getRoot());
            this.cardBinding=cardviewBinding;
        }
    }
}

